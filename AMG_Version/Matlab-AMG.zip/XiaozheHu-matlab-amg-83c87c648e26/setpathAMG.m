
% set path of AMG package
% 
% @ Xiaozhe Hu, Tufts University

addpath(genpath(pwd));
