function [x] = jacobi(A, b, x, Dinv, nsmooth)
% Jacobi Method
%
% @ Xiaozhe Hu, Tufts University

%----------------------------
% Step 1: Main loop
%----------------------------
for i = 1:nsmooth
    
    % Jacobi iteration
    x = x + Dinv.*(b-A*x);          % x_{k+1} = x_k + B(b-Ax_k), B = inv(D)
    
end